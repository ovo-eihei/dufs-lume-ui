Dufs Lume UI
==============

A modern skin for the dufs static file server, shipped as a flat
asset bundle and mounted with `dufs --assets ./dist`.

See https://github.com/ovo-eihei/dufs-lume-ui
